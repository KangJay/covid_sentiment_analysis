import pandas as pd

data = pd.read_csv("./dec_01_2020.csv")
print(data.columns)
